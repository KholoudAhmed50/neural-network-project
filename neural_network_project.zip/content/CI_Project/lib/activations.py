import numpy as np

class Activation(Layer):
    def __init__(self):
        super().__init__()
        
    def forward(self, input):
        self.input = input
        self.output = self.activation(input)
        return self.output
    
    def backward(self, output_gradient, learning_rate):
        return output_gradient * self.activation_derivative(self.input)
    
    def activation(self, x):
        raise NotImplementedError
    
    def activation_derivative(self, x):
        raise NotImplementedError

class ReLU(Activation):
    def activation(self, x):
        return np.maximum(0, x)
    
    def activation_derivative(self, x):
        return np.where(x > 0, 1, 0)

class Sigmoid(Activation):
    def activation(self, x):
        return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
    
    def activation_derivative(self, x):
        sig = self.activation(x)
        return sig * (1 - sig)

class Tanh(Activation):
    def activation(self, x):
        return np.tanh(x)
    
    def activation_derivative(self, x):
        return 1 - np.tanh(x) ** 2
