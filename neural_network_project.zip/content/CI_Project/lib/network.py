import numpy as np

class Sequential:
    def __init__(self):
        self.layers = []
        self.loss = None
        self.optimizer = None
        
    def add(self, layer):
        self.layers.append(layer)
        
    def set_loss(self, loss):
        self.loss = loss
        
    def set_optimizer(self, optimizer):
        self.optimizer = optimizer
        
    def forward(self, X):
        output = X
        for layer in self.layers:
            output = layer.forward(output)
        return output
    
    def backward(self, loss_gradient, learning_rate):
        grad = loss_gradient
        for i in reversed(range(len(self.layers))):
            grad = self.layers[i].backward(grad, learning_rate)
    
    def predict(self, X):
        return self.forward(X)
    
    def train(self, X_train, y_train, epochs=1000, learning_rate=0.01, 
              batch_size=32, verbose=True, validation_data=None):
        history = {'loss': [], 'val_loss': []}
        
        for epoch in range(epochs):
            indices = np.arange(len(X_train))
            np.random.shuffle(indices)
            X_shuffled = X_train[indices]
            y_shuffled = y_train[indices]
            
            epoch_loss = 0
            num_batches = max(1, len(X_train) // batch_size)
            
            for batch in range(num_batches):
                start = batch * batch_size
                end = start + batch_size
                X_batch = X_shuffled[start:end]
                y_batch = y_shuffled[start:end]
                
                y_pred = self.forward(X_batch)
                batch_loss = self.loss.calculate(y_pred, y_batch)
                epoch_loss += batch_loss
                
                loss_gradient = self.loss.gradient(y_pred, y_batch)
                self.backward(loss_gradient, learning_rate)
            
            epoch_loss /= num_batches
            history['loss'].append(epoch_loss)
            
            if validation_data is not None:
                X_val, y_val = validation_data
                y_val_pred = self.predict(X_val)
                val_loss = self.loss.calculate(y_val_pred, y_val)
                history['val_loss'].append(val_loss)
            
            if verbose and epoch % 100 == 0:
                val_info = f", Val Loss: {val_loss:.4f}" if validation_data else ""
                print(f"Epoch {epoch}, Loss: {epoch_loss:.4f}{val_info}")
        
        return history
