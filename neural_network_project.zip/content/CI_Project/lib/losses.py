import numpy as np

class Loss:
    def __init__(self):
        pass
    
    def calculate(self, y_pred, y_true):
        raise NotImplementedError
    
    def gradient(self, y_pred, y_true):
        raise NotImplementedError

class MSE(Loss):
    def calculate(self, y_pred, y_true):
        return np.mean(np.square(y_true - y_pred))
    
    def gradient(self, y_pred, y_true):
        return -2 * (y_true - y_pred) / y_true.size
