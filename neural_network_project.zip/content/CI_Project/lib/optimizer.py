import numpy as np

class SGD:
    def __init__(self, learning_rate=0.01, momentum=0.0):
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.velocities = {}
        
    def update(self, layer, layer_id):
        if layer_id not in self.velocities:
            self.velocities[layer_id] = {
                'weights': np.zeros_like(layer.weights),
                'bias': np.zeros_like(layer.bias)
            }
        
        v_w = self.velocities[layer_id]['weights']
        v_b = self.velocities[layer_id]['bias']
        
        v_w = self.momentum * v_w - self.learning_rate * layer.weights_gradient
        v_b = self.momentum * v_b - self.learning_rate * layer.bias_gradient
        
        layer.weights += v_w
        layer.bias += v_b
        
        self.velocities[layer_id] = {'weights': v_w, 'bias': v_b}
