# Neural Network Library from Scratch

## Project Overview
Implementation of a neural network library from scratch using only NumPy.

## Project Structure
